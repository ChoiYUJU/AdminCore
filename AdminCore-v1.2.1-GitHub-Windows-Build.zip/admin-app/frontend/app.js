const $ = (s, r = document) => r.querySelector(s);
const el = (tag, text, cls) => { const e = document.createElement(tag); if (text != null) e.textContent = text; if (cls) e.className = cls; return e; };
const jsonOpts = (method, body) => ({ method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

async function api(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) {
    let m = await r.text();
    try { m = JSON.parse(m).detail || m; } catch {}
    throw new Error(typeof m === "string" ? m : JSON.stringify(m));
  }
  return r.json();
}

/* ------------------------------------------------------------ data tetap */
const PT = {
  vip: { kode: "VIP", nama: "PT VIP", lengkap: "PT. VIP Binaa Sejahtera" },
  mika: { kode: "MIKA", nama: "Mika Management", lengkap: "Mika Management" },
};
const NAV = [
  { id: "ringkasan", nama: "Ringkasan" },
  { grup: "People & Organization" },
  { id: "karyawan/vip", nama: PT.vip.nama },
  { id: "karyawan/mika", nama: PT.mika.nama },
  { grup: "Document Center" },
  { id: "surat", nama: "Surat", segera: true, ket: "Pembuat surat tugas, perintah tugas, peringatan, teguran, dan permohonan." },
  { id: "bpjs", nama: "BPJS", segera: true, ket: "Pencatatan iuran BPJS bulanan per area." },
  { id: "arsip", nama: "Arsip", segera: true, ket: "Penyimpanan dokumen berdasarkan area, jenis, tahun, dan bulan." },
  { grup: "System" },
  { id: "aktivitas", nama: "Log Aktivitas" },
];
const LABEL_AKSI = {
  tambah_area: "Area ditambahkan", tambah_karyawan: "Karyawan ditambahkan", ubah_karyawan: "Data karyawan diubah",
  karyawan_keluar: "Karyawan keluar", karyawan_aktif_kembali: "Karyawan diaktifkan kembali", impor_excel: "Impor Excel",
};
const labelAksi = (v) => LABEL_AKSI[v] || String(v || "Aktivitas").replaceAll("_", " ");
function formatWaktu(v) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? (v || "") : d.toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" });
}

/* ------------------------------------------------------------------ router */
function bangunNav() {
  const nav = $("#nav");
  NAV.forEach((m) => {
    if (m.grup) return nav.append(el("div", m.grup, "grup"));
    const a = el("a"); a.href = "#/" + m.id; a.dataset.id = m.id;
    const ikon = { ringkasan: "▦", "karyawan/vip": "V", "karyawan/mika": "M", surat: "↗", bpjs: "+", arsip: "▤", aktivitas: "◷" };
    a.append(el("span", ikon[m.id] || "·", "nav-icon"), el("span", m.nama, "nav-label"));
    if (m.segera) a.append(el("span", "Soon", "tag"));
    nav.append(a);
  });
}

function tampil() {
  const bagian = location.hash.replace(/^#\/?/, "").split("/");
  let halaman = bagian[0] || "ringkasan", param = bagian[1];
  if (halaman === "beranda") halaman = "ringkasan";
  const main = $("#halaman");
  main.replaceChildren();
  const idNav = param ? halaman + "/" + param : halaman;
  document.querySelectorAll("#nav a").forEach((a) => a.classList.toggle("aktif", a.dataset.id === idNav));
  const item = NAV.find((m) => m.id === idNav);
  document.title = (item ? item.nama + " · " : "") + "AdminCore";

  if (halaman === "ringkasan") { main.append($("#t-ringkasan").content.cloneNode(true)); mountRingkasan(main); }
  else if (halaman === "karyawan" && PT[param]) { main.append($("#t-karyawan").content.cloneNode(true)); mountKaryawan(main, param); }
  else if (halaman === "aktivitas") { main.append($("#t-aktivitas").content.cloneNode(true)); mountAktivitas(main); }
  else if (item && item.segera) {
    main.append($("#t-segera").content.cloneNode(true));
    $("#segNama").textContent = item.nama; $("#segKet").textContent = item.ket;
  } else location.hash = "#/ringkasan";
}

/* --------------------------------------------------------------- ringkasan */
async function mountRingkasan(root) {
  const panel = $("#panelPT", root), log = $("#aktivitasRingkas", root);
  try {
    const r = await api("/api/ringkasan");
    ["vip", "mika"].forEach((key) => {
      const d = r.perusahaan[PT[key].kode];
      const p = el("div", null, "panel");
      const kepala = el("div", null, "panel-kepala");
      const a = el("a", "Buka database →"); a.href = "#/karyawan/" + key;
      kepala.append(el("h3", PT[key].lengkap), a);
      const angka = el("div", null, "angka");
      [[d.aktif, "Aktif"], [d.keluar, "Keluar"], [d.perlu_cek, "Perlu dicek"]].forEach(([n, l]) => {
        const x = el("div"); x.append(el("b", n), el("span", l)); angka.append(x);
      });
      p.append(kepala, angka);
      if (!d.area.length) p.append(el("div", "Belum ada area.", "baris"));
      d.area.forEach((ar) => { const b = el("div", null, "baris"); b.append(el("span", ar.nama), el("span", ar.aktif + " aktif")); p.append(b); });
      panel.append(p);
    });
  } catch (e) { panel.append(el("div", e.message, "kosong")); }
  try {
    const data = await api("/api/aktivitas?limit=6");
    if (!data.length) log.append(el("div", "Belum ada aktivitas.", "kosong"));
    data.forEach((a) => {
      const i = el("div", null, "log-item");
      i.append(el("span", formatWaktu(a.waktu), "log-waktu"), el("span", labelAksi(a.aksi), "log-aksi"), el("span", a.keterangan));
      log.append(i);
    });
  } catch (e) { log.append(el("div", e.message, "kosong")); }
}

/* ---------------------------------------------------------------- aktivitas */
async function mountAktivitas(root) {
  const list = $("#logList", root);
  async function muat() {
    list.replaceChildren(el("div", "Memuat…", "kosong"));
    try {
      const data = await api("/api/aktivitas?limit=" + $("#batas", root).value);
      list.replaceChildren();
      if (!data.length) return list.append(el("div", "Belum ada aktivitas.", "kosong"));
      data.forEach((a) => {
        const i = el("div", null, "log-item");
        i.append(el("span", formatWaktu(a.waktu), "log-waktu"), el("span", labelAksi(a.aksi), "log-aksi"), el("span", a.keterangan));
        list.append(i);
      });
    } catch (e) { list.replaceChildren(el("div", e.message, "kosong")); }
  }
  $("#muat", root).onclick = muat;
  $("#batas", root).onchange = muat;
  await muat();
}

/* ----------------------------------------------------------------- karyawan */
async function mountKaryawan(root, key) {
  const pt = PT[key], q = (s) => $(s, root);
  let areas = [], rows = [], editId = null, tunda;
  q("#judulHal").textContent = "Database Karyawan · " + pt.nama;
  q("#subJudul").textContent = pt.lengkap;

  async function muatArea(pilih) {
    areas = await api("/api/areas?perusahaan=" + pt.kode);
    const sel = q("#area");
    sel.replaceChildren(new Option("Semua area", ""));
    areas.forEach((a) => sel.add(new Option(a.nama, a.id)));
    if (pilih) sel.value = pilih;
    const f = q("#form [name=area_id]");
    f.replaceChildren();
    areas.forEach((a) => f.add(new Option(a.nama, a.id)));
    ["#btnTambah", "#btnImpor", "#btnEkspor"].forEach((id) => (q(id).disabled = !areas.length));
  }

  async function muatData() {
    const kosong = q("#kosong");
    if (!areas.length) {
      rows = []; gambar();
      kosong.hidden = false; kosong.textContent = "Belum ada area. Klik “Tambah area” untuk memulai.";
      return;
    }
    const p = new URLSearchParams({ perusahaan: pt.kode });
    if (q("#area").value) p.set("area_id", q("#area").value);
    if (q("#status").value) p.set("status", q("#status").value);
    if (q("#cari").value.trim()) p.set("q", q("#cari").value.trim());
    rows = await api("/api/karyawan?" + p);
    gambar();
    kosong.hidden = rows.length > 0;
    kosong.textContent = "Tidak ada data yang cocok.";
  }

  function gambar() {
    const tb = q("#isi");
    tb.replaceChildren();
    rows.forEach((r, i) => {
      const tr = el("tr", null, r.status === "keluar" ? "keluar" : "");
      [i + 1, r.nama, r.jabatan, r.area, r.tempat_tanggal_lahir, r.nik, r.no_hp, r.no_rekening].forEach((v, c) => {
        const td = el("td", v);
        if (c === 1 && r.peringatan.length) { const w = el("span", "Cek", "cek"); w.title = r.peringatan.join(", "); td.append(w); }
        tr.append(td);
      });
      const st = el("td"); st.append(el("span", r.status === "aktif" ? "Aktif" : "Keluar", "status " + (r.status === "keluar" ? "keluar" : "")));
      tr.append(st);
      const aksi = el("td");
      const be = el("button", "Edit", "kecil sek"); be.onclick = () => bukaForm(r);
      aksi.append(be, " ");
      if (r.status === "aktif") { const bk = el("button", "Keluar", "kecil bahaya"); bk.onclick = () => keluar(r); aksi.append(bk); }
      else { const ba = el("button", "Aktifkan", "kecil sek"); ba.onclick = () => aktifkan(r); aksi.append(ba); }
      tr.append(aksi);
      tb.append(tr);
    });
    const cek = rows.filter((r) => r.peringatan.length).length;
    q("#info").textContent = `${rows.length} karyawan` + (cek ? ` · ${cek} data perlu dicek (NIK, HP, atau rekening ganda)` : "");
  }

  function bukaForm(r) {
    editId = r ? r.id : null;
    q("#judulForm").textContent = r ? "Edit karyawan" : "Tambah karyawan";
    const f = q("#form");
    f.reset();
    q("#galat").textContent = "";
    const data = r || { area_id: q("#area").value || (areas[0] && areas[0].id) };
    for (const x of f.elements) if (x.name && data[x.name] != null) x.value = data[x.name];
    q("#dlg").showModal();
  }

  async function simpan(e) {
    e.preventDefault();
    const body = Object.fromEntries(new FormData(q("#form")));
    body.area_id = Number(body.area_id);
    body.tanggal_masuk = body.tanggal_masuk || null;
    try {
      await api(editId ? "/api/karyawan/" + editId : "/api/karyawan", jsonOpts(editId ? "PUT" : "POST", body));
      q("#dlg").close();
      await muatData();
    } catch (err) { q("#galat").textContent = err.message; }
  }

  async function keluar(r) {
    if (!confirm(`Tandai ${r.nama} sebagai keluar hari ini?`)) return;
    try { await api(`/api/karyawan/${r.id}/keluar`, jsonOpts("POST", {})); await muatData(); } catch (e) { alert(e.message); }
  }
  async function aktifkan(r) {
    try { await api(`/api/karyawan/${r.id}/aktif`, jsonOpts("POST", {})); await muatData(); } catch (e) { alert(e.message); }
  }

  async function tambahArea() {
    const nama = prompt(`Nama area baru untuk ${pt.nama}:`);
    if (!nama) return;
    try {
      const a = await api("/api/areas", jsonOpts("POST", { nama, perusahaan: pt.kode }));
      await muatArea(a.id); await muatData();
    } catch (e) { alert(e.message); }
  }

  async function impor() {
    const file = q("#fileImpor").files[0];
    q("#fileImpor").value = "";
    if (!file) return;
    const areaId = q("#area").value || (areas.length === 1 ? areas[0].id : "");
    if (!areaId) return alert("Pilih area tujuan terlebih dahulu (bukan “Semua area”), lalu impor.");
    const fd = new FormData();
    fd.append("file", file);
    try {
      const h = await api("/api/karyawan/impor?area_id=" + areaId, { method: "POST", body: fd });
      alert(`Sheet "${h.sheet}": ${h.ditambah} karyawan ditambahkan, ${h.dilewati.length} dilewati (NIK sudah ada).`);
      await muatData();
    } catch (e) { alert(e.message); }
  }

  async function ekspor() {
    const p = new URLSearchParams({ perusahaan: pt.kode });
    if (q("#area").value) p.set("area_id", q("#area").value);
    try {
      const h = await api("/api/karyawan/ekspor?" + p, { method: "POST" });
      if (confirm(`${h.jumlah} karyawan diekspor ke:\n${h.path}\n\nBuka file sekarang?`)) await api("/api/buka", jsonOpts("POST", { path: h.path }));
    } catch (e) { alert(e.message); }
  }

  q("#cari").oninput = () => { clearTimeout(tunda); tunda = setTimeout(muatData, 250); };
  q("#area").onchange = q("#status").onchange = muatData;
  q("#btnTambah").onclick = () => bukaForm(null);
  q("#btnArea").onclick = tambahArea;
  q("#btnImpor").onclick = () => q("#fileImpor").click();
  q("#fileImpor").onchange = impor;
  q("#btnEkspor").onclick = ekspor;
  q("#batal").onclick = () => q("#dlg").close();
  q("#form").onsubmit = simpan;

  try { await muatArea(); await muatData(); } catch (e) { q("#info").textContent = e.message; }
}

/* -------------------------------------------------------------------- mulai */
bangunNav();
window.addEventListener("hashchange", tampil);
tampil();
