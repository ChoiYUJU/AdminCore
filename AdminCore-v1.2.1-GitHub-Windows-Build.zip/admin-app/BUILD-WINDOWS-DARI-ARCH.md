# Build AdminCore Windows dari Arch Linux

Kamu tidak perlu memiliki Windows. Workflow GitHub Actions di `.github/workflows/windows-build.yml` akan memakai runner Windows milik GitHub untuk membuat:

- `AdminCore.exe` (portable)
- `AdminCore-Setup-1.2.0.exe` (installer)

## Langkah
1. Buat repository GitHub baru, misalnya `admincore`.
2. Upload/push seluruh isi folder `admin-app` ke repository tersebut.
3. Buka tab **Actions** di GitHub dan izinkan Actions jika diminta.
4. Pilih **Build AdminCore for Windows** → **Run workflow**.
5. Tunggu sampai job hijau selesai.
6. Buka hasil run, bagian **Artifacts**, lalu unduh `AdminCore-Windows-...zip`.

Build berjalan di mesin Windows cloud GitHub, bukan di laptop Arch kamu. Jangan unggah database produksi atau data karyawan asli ke repository. Gunakan database uji kosong.

Catatan: build sukses belum menggantikan pengujian aplikasi pada Windows sungguhan. Untuk pengujian awal, gunakan Windows VM/cloud atau minta satu pengguna Windows mencoba paketnya. Pastikan WebView2 Runtime tersedia pada komputer uji.
