from datetime import date, datetime
from typing import Optional

from sqlalchemy import Date, DateTime, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Area(Base):
    __tablename__ = "area"
    id: Mapped[int] = mapped_column(primary_key=True)
    nama: Mapped[str] = mapped_column(String(120))
    perusahaan: Mapped[str] = mapped_column(String(10), default="VIP")  # VIP | MIKA


class Karyawan(Base):
    __tablename__ = "karyawan"
    id: Mapped[int] = mapped_column(primary_key=True)
    area_id: Mapped[int] = mapped_column(ForeignKey("area.id"))
    nama: Mapped[str] = mapped_column(String(200))
    jabatan: Mapped[str] = mapped_column(String(80), default="")
    tempat_tanggal_lahir: Mapped[str] = mapped_column(String(120), default="")
    nik: Mapped[str] = mapped_column(String(32), default="")
    alamat: Mapped[str] = mapped_column(Text, default="")
    no_rekening: Mapped[str] = mapped_column(String(40), default="")
    email: Mapped[str] = mapped_column(String(120), default="")
    no_hp: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(10), default="aktif")  # aktif | keluar
    tanggal_masuk: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    tanggal_keluar: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    catatan: Mapped[str] = mapped_column(Text, default="")

    area: Mapped[Area] = relationship()


class LogPerubahan(Base):
    __tablename__ = "log_perubahan"
    id: Mapped[int] = mapped_column(primary_key=True)
    waktu: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    aksi: Mapped[str] = mapped_column(String(40))
    keterangan: Mapped[str] = mapped_column(Text, default="")
