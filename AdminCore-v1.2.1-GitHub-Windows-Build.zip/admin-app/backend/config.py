"""Pengaturan dokumen per perusahaan (judul Excel, penanda tangan, logo).
Bisa diedit di data/pengaturan_dokumen.json (dibuat otomatis saat ekspor pertama)."""
import json
from pathlib import Path

from .database import DATA_DIR
from .paths import resource_path

ASSETS = resource_path("backend", "assets")

BAWAAN = {
    "VIP": {
        "perusahaan": "PT. VIP BINAA SEJAHTERA",
        "unit": "SPESIAL SERVICE",
        "label_penanggung_jawab": "Penanggung Jawab Perusahaan",
        "penandatangan": "Ismail Situju Ramo, S.Pd",
        "jabatan_penandatangan": "Direktur",
        "logo": "logo.png",
    },
    "MIKA": {
        "perusahaan": "MIKA MANAGEMENT",
        "unit": "",
        "label_penanggung_jawab": "Penanggung Jawab Perusahaan",
        "penandatangan": "",
        "jabatan_penandatangan": "",
        "logo": "logo-mika.png",
    },
}


def muat(kode: str) -> dict:
    kode = kode.upper()
    f = DATA_DIR / "pengaturan_dokumen.json"
    data = {k: dict(v) for k, v in BAWAAN.items()}
    if f.exists():
        try:
            for k, v in json.loads(f.read_text(encoding="utf-8")).items():
                if k in data and isinstance(v, dict):
                    data[k].update(v)
        except Exception:
            pass
    else:
        f.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    cfg = data[kode]
    cfg["logo_path"] = str(ASSETS / cfg.get("logo", ""))
    return cfg
