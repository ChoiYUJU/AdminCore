"""Lokasi resource aplikasi dan data pengguna untuk mode source maupun PyInstaller."""
import os
import shutil
import sys
from pathlib import Path


def resource_dir() -> Path:
    """Folder resource yang dibundel PyInstaller atau folder proyek saat development."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent.parent


def project_dir() -> Path:
    """Folder executable saat frozen; folder proyek saat development."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _data_dir() -> Path:
    if sys.platform.startswith("win"):
        root = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
        target = root / "AdminCore"
        legacy = project_dir() / "data"
    else:
        # Pertahankan perilaku development Linux/macOS yang sudah ada.
        target = project_dir() / "data"
        legacy = None

    target.mkdir(parents=True, exist_ok=True)

    # Migrasi aman satu kali: hanya salin jika lokasi AppData belum punya database.
    # Tidak pernah menimpa database atau konfigurasi yang sudah ada.
    if legacy and legacy.resolve() != target.resolve():
        old_db = legacy / "app.db"
        new_db = target / "app.db"
        if old_db.is_file() and not new_db.exists():
            shutil.copy2(old_db, new_db)
            for name in ("pengaturan_dokumen.json",):
                old_file, new_file = legacy / name, target / name
                if old_file.is_file() and not new_file.exists():
                    shutil.copy2(old_file, new_file)
            old_exports = legacy / "ekspor"
            new_exports = target / "ekspor"
            if old_exports.is_dir() and not new_exports.exists():
                shutil.copytree(old_exports, new_exports)
    return target


DATA_DIR = _data_dir()


def resource_path(*parts: str) -> Path:
    return resource_dir().joinpath(*parts)
