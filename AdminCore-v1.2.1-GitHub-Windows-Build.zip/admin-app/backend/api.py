import os
import re
import subprocess
import sys
from collections import Counter
from datetime import date, datetime
from io import BytesIO
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import config
from .database import DATA_DIR, get_db
from .models import Area, Karyawan, LogPerubahan
from .services import excel

router = APIRouter(prefix="/api")
KODE = ("VIP", "MIKA")


def _kode(v: Optional[str]) -> str:
    v = (v or "").upper()
    if v not in KODE:
        raise HTTPException(400, "Perusahaan harus VIP atau MIKA.")
    return v


# ---------- skema ----------
class AreaIn(BaseModel):
    nama: str
    perusahaan: str = "VIP"


class KaryawanIn(BaseModel):
    area_id: int
    nama: str
    jabatan: str = ""
    tempat_tanggal_lahir: str = ""
    nik: str = ""
    alamat: str = ""
    no_rekening: str = ""
    email: str = ""
    no_hp: str = ""
    tanggal_masuk: Optional[date] = None
    catatan: str = ""


class KeluarIn(BaseModel):
    tanggal_keluar: Optional[date] = None


class BukaIn(BaseModel):
    path: str


def _bersihkan(d: dict) -> dict:
    d = {k: (v.strip() if isinstance(v, str) else v) for k, v in d.items()}
    for k in ("nama", "jabatan"):
        if k in d:
            d[k] = d[k].upper()
    if "email" in d:
        d["email"] = d["email"].lower()
    return d


def _log(db: Session, aksi: str, ket: str):
    db.add(LogPerubahan(aksi=aksi, keterangan=ket))


def _out(k: Karyawan, peringatan=None) -> dict:
    return {
        "id": k.id, "area_id": k.area_id, "area": k.area.nama, "perusahaan": k.area.perusahaan,
        "nama": k.nama, "jabatan": k.jabatan,
        "tempat_tanggal_lahir": k.tempat_tanggal_lahir, "nik": k.nik, "alamat": k.alamat,
        "no_rekening": k.no_rekening, "email": k.email, "no_hp": k.no_hp, "status": k.status,
        "tanggal_masuk": k.tanggal_masuk.isoformat() if k.tanggal_masuk else None,
        "tanggal_keluar": k.tanggal_keluar.isoformat() if k.tanggal_keluar else None,
        "catatan": k.catatan, "peringatan": peringatan or [],
    }


def _peringatan_ganda(semua: list[Karyawan]) -> dict[int, list[str]]:
    """Tandai NIK / HP / rekening ganda di antara karyawan aktif, dihitung per perusahaan."""
    label = {"nik": "NIK ganda", "no_hp": "No. HP ganda", "no_rekening": "No. rekening ganda"}
    hasil: dict[int, list[str]] = {}
    for kode in KODE:
        aktif = [k for k in semua if k.status == "aktif" and k.area.perusahaan == kode]
        hitung = {f: Counter(getattr(k, f) for k in aktif if getattr(k, f)) for f in label}
        for k in aktif:
            w = [label[f] for f in label if getattr(k, f) and hitung[f][getattr(k, f)] > 1]
            if w:
                hasil[k.id] = w
    return hasil


def _nik_dipakai(db: Session, nik: str, perusahaan: str, kecuali: Optional[int] = None) -> bool:
    if not nik:
        return False
    q = (select(Karyawan.id).join(Area, Karyawan.area_id == Area.id)
         .where(Karyawan.nik == nik, Area.perusahaan == perusahaan))
    if kecuali:
        q = q.where(Karyawan.id != kecuali)
    return db.scalar(q) is not None


# ---------- area ----------
@router.get("/areas")
def daftar_area(perusahaan: Optional[str] = None, db: Session = Depends(get_db)):
    q = select(Area).order_by(Area.nama)
    if perusahaan:
        q = q.where(Area.perusahaan == _kode(perusahaan))
    return [{"id": a.id, "nama": a.nama, "perusahaan": a.perusahaan} for a in db.scalars(q)]


@router.post("/areas")
def tambah_area(data: AreaIn, db: Session = Depends(get_db)):
    nama, kode = data.nama.strip(), _kode(data.perusahaan)
    if not nama:
        raise HTTPException(400, "Nama area tidak boleh kosong.")
    if db.scalar(select(Area).where(Area.nama == nama, Area.perusahaan == kode)):
        raise HTTPException(400, "Area sudah ada di perusahaan ini.")
    a = Area(nama=nama, perusahaan=kode)
    db.add(a)
    _log(db, "tambah_area", f"{nama} ({kode})")
    db.commit()
    return {"id": a.id, "nama": a.nama, "perusahaan": a.perusahaan}


# ---------- karyawan ----------
@router.get("/karyawan")
def daftar_karyawan(perusahaan: Optional[str] = None, area_id: Optional[int] = None,
                    status: Optional[str] = None, q: str = "", db: Session = Depends(get_db)):
    kode = _kode(perusahaan) if perusahaan else None
    semua = list(db.scalars(select(Karyawan)))
    ganda = _peringatan_ganda(semua)
    q = q.strip().lower()
    hasil = []
    for k in sorted(semua, key=lambda x: (x.area.nama, x.nama)):
        if kode and k.area.perusahaan != kode:
            continue
        if area_id and k.area_id != area_id:
            continue
        if status and k.status != status:
            continue
        if q and q not in f"{k.nama} {k.jabatan} {k.nik} {k.no_hp}".lower():
            continue
        hasil.append(_out(k, ganda.get(k.id)))
    return hasil


@router.post("/karyawan")
def tambah_karyawan(data: KaryawanIn, db: Session = Depends(get_db)):
    d = _bersihkan(data.model_dump())
    if not d["nama"]:
        raise HTTPException(400, "Nama wajib diisi.")
    area = db.get(Area, d["area_id"])
    if not area:
        raise HTTPException(400, "Area tidak ditemukan.")
    if _nik_dipakai(db, d["nik"], area.perusahaan):
        raise HTTPException(400, "NIK sudah terdaftar di database ini.")
    k = Karyawan(**d)
    db.add(k)
    _log(db, "tambah_karyawan", f"{k.nama} ({area.perusahaan})")
    db.commit()
    return _out(k)


@router.put("/karyawan/{kid}")
def ubah_karyawan(kid: int, data: KaryawanIn, db: Session = Depends(get_db)):
    k = db.get(Karyawan, kid)
    if not k:
        raise HTTPException(404, "Karyawan tidak ditemukan.")
    d = _bersihkan(data.model_dump())
    area = db.get(Area, d["area_id"])
    if not area:
        raise HTTPException(400, "Area tidak ditemukan.")
    if area.perusahaan != k.area.perusahaan:
        raise HTTPException(400, "Karyawan tidak bisa dipindah antar perusahaan.")
    if _nik_dipakai(db, d["nik"], area.perusahaan, kecuali=kid):
        raise HTTPException(400, "NIK sudah dipakai karyawan lain.")
    berubah = [f for f, v in d.items() if getattr(k, f) != v]
    for f, v in d.items():
        setattr(k, f, v)
    _log(db, "ubah_karyawan", f"{k.nama}: {', '.join(berubah) or 'tanpa perubahan'}")
    db.commit()
    return _out(k)


@router.post("/karyawan/{kid}/keluar")
def karyawan_keluar(kid: int, data: KeluarIn, db: Session = Depends(get_db)):
    k = db.get(Karyawan, kid)
    if not k:
        raise HTTPException(404, "Karyawan tidak ditemukan.")
    k.status = "keluar"
    k.tanggal_keluar = data.tanggal_keluar or date.today()
    _log(db, "karyawan_keluar", k.nama)
    db.commit()
    return _out(k)


@router.post("/karyawan/{kid}/aktif")
def karyawan_aktif(kid: int, db: Session = Depends(get_db)):
    k = db.get(Karyawan, kid)
    if not k:
        raise HTTPException(404, "Karyawan tidak ditemukan.")
    k.status, k.tanggal_keluar = "aktif", None
    _log(db, "karyawan_aktif_kembali", k.nama)
    db.commit()
    return _out(k)


@router.post("/karyawan/impor")
async def impor_karyawan(area_id: int, file: UploadFile = File(...), sheet: Optional[str] = None,
                         db: Session = Depends(get_db)):
    area = db.get(Area, area_id)
    if not area:
        raise HTTPException(400, "Pilih area tujuan terlebih dahulu.")
    try:
        baris, nama_sheet = excel.baca_karyawan(BytesIO(await file.read()), sheet or None)
    except Exception as e:
        raise HTTPException(400, f"Gagal membaca Excel: {e}")
    nik_ada = {n for n in db.scalars(select(Karyawan.nik).join(Area, Karyawan.area_id == Area.id)
                                     .where(Area.perusahaan == area.perusahaan)) if n}
    tambah, lewati = 0, []
    for b in baris:
        b = _bersihkan(b)
        if b.get("nik") and b["nik"] in nik_ada:
            lewati.append(b["nama"])
            continue
        db.add(Karyawan(area_id=area_id, **b))
        if b.get("nik"):
            nik_ada.add(b["nik"])
        tambah += 1
    _log(db, "impor_excel", f"{file.filename} [{nama_sheet}] ke {area.nama} ({area.perusahaan}): "
                            f"{tambah} ditambah, {len(lewati)} dilewati")
    db.commit()
    return {"sheet": nama_sheet, "ditambah": tambah, "dilewati": lewati}


@router.post("/karyawan/ekspor")
def ekspor_karyawan(perusahaan: str, area_id: Optional[int] = None, db: Session = Depends(get_db)):
    kode = _kode(perusahaan)
    q = select(Area).where(Area.perusahaan == kode).order_by(Area.nama)
    if area_id:
        q = q.where(Area.id == area_id)
    areas = list(db.scalars(q))
    if not areas:
        raise HTTPException(400, "Area tidak ditemukan.")
    grup, keluar = [], []
    for a in areas:
        anggota = sorted(db.scalars(select(Karyawan).where(Karyawan.area_id == a.id)), key=lambda k: k.nama)
        aktif = [_out(k) for k in anggota if k.status == "aktif"]
        keluar += [_out(k) for k in anggota if k.status == "keluar"]
        if aktif or area_id:
            grup.append((a.nama, aktif))
    folder = DATA_DIR / "ekspor"
    folder.mkdir(exist_ok=True)
    label = areas[0].nama if area_id else "SEMUA AREA"
    path = folder / f"Database_{kode}_{re.sub(r'[^A-Za-z0-9]+', '_', label)}_{datetime.now():%Y%m%d_%H%M%S}.xlsx"
    excel.tulis_database(path, grup, keluar, config.muat(kode))
    return {"path": str(path), "jumlah": sum(len(g[1]) for g in grup)}


# ---------- ringkasan, aktivitas, utilitas ----------
@router.get("/ringkasan")
def ringkasan(db: Session = Depends(get_db)):
    semua = list(db.scalars(select(Karyawan)))
    areas = list(db.scalars(select(Area).order_by(Area.nama)))
    ganda = _peringatan_ganda(semua)
    hasil = {}
    for kode in KODE:
        ks = [k for k in semua if k.area.perusahaan == kode]
        hasil[kode] = {
            "aktif": sum(1 for k in ks if k.status == "aktif"),
            "keluar": sum(1 for k in ks if k.status == "keluar"),
            "perlu_cek": sum(1 for k in ks if k.id in ganda),
            "area": [{"nama": a.nama, "aktif": sum(1 for k in ks if k.area_id == a.id and k.status == "aktif")}
                     for a in areas if a.perusahaan == kode],
        }
    return {"perusahaan": hasil}


@router.get("/aktivitas")
def daftar_aktivitas(limit: int = 50, db: Session = Depends(get_db)):
    batas = max(1, min(limit, 200))
    logs = db.scalars(select(LogPerubahan).order_by(LogPerubahan.waktu.desc()).limit(batas))
    return [{"id": x.id, "waktu": x.waktu.isoformat(timespec="minutes"), "aksi": x.aksi,
             "keterangan": x.keterangan} for x in logs]


@router.post("/buka")
def buka_berkas(data: BukaIn):
    """Buka file hasil ekspor dengan aplikasi bawaan sistem (hanya di dalam folder data/)."""
    p = Path(data.path).resolve()
    if DATA_DIR.resolve() not in p.parents or not p.exists():
        raise HTTPException(400, "Berkas tidak ditemukan.")
    if sys.platform.startswith("win"):
        os.startfile(p)  # noqa
    else:
        subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", str(p)])
    return {"ok": True}
