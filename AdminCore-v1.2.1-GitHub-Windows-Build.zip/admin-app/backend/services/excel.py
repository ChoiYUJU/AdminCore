"""Baca dan tulis Excel database karyawan (mengikuti format file perusahaan)."""
import re
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L
from openpyxl.worksheet.properties import PageSetupProperties

from ..paths import resource_path

# kunci kolom -> kemungkinan judul kolom di Excel
KOLOM = {
    "nama": ["NAMA"],
    "jabatan": ["JABATAN"],
    "tempat_tanggal_lahir": ["TEMPAT/TANGGAL LAHIR", "TTL", "TEMPAT TANGGAL LAHIR"],
    "nik": ["NIK KTP", "NIK"],
    "alamat": ["ALAMAT"],
    "no_rekening": ["NOMOR REKENING", "NO REKENING", "NO. REKENING", "REKENING"],
    "email": ["GMAIL", "EMAIL", "E-MAIL"],
    "no_hp": ["NO HP", "NO. HP", "NOMOR HP", "HP"],
}


def _teks(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def baca_karyawan(file_obj, sheet: str | None = None):
    """Mengembalikan (daftar_baris, nama_sheet). Baris = dict sesuai kunci KOLOM."""
    wb = load_workbook(file_obj, read_only=True, data_only=True)
    ws = wb[sheet] if sheet else wb[wb.sheetnames[0]]
    peta, hasil, mulai = {}, [], False
    for row in ws.iter_rows(values_only=True):
        if not mulai:
            judul = [_teks(c).upper() for c in row]
            if "NAMA" in judul:  # baris judul ditemukan
                for kunci, opsi in KOLOM.items():
                    for i, j in enumerate(judul):
                        if j in opsi:
                            peta[kunci] = i
                            break
                mulai = True
            continue
        item = {k: _teks(row[i]) if i < len(row) else "" for k, i in peta.items()}
        if item.get("nama"):
            hasil.append(item)
    wb.close()
    if not mulai:
        raise ValueError("Baris judul dengan kolom NAMA tidak ditemukan di sheet ini.")
    return hasil, ws.title



# ---------------------------------------------------------------------------
# Ekspor: mengikuti format file contoh (judul, header kuning, border, tanda tangan)
# ---------------------------------------------------------------------------
LOGO = resource_path("backend", "assets", "logo.png")
TIPIS = Side(style="thin")
BORDER = Border(left=TIPIS, right=TIPIS, top=TIPIS, bottom=TIPIS)
KUNING = PatternFill("solid", fgColor="FFFF00")
TENGAH = Alignment(horizontal="center", vertical="center", wrap_text=True)
KIRI = Alignment(horizontal="left", vertical="center", wrap_text=True)

# (judul kolom, kunci data, lebar, rata)
KOLOM_AKTIF = [
    ("NO", None, 9.4, "c"), ("NAMA", "nama", 45.7, "l"), ("JABATAN", "jabatan", 23.3, "c"),
    ("TEMPAT/TANGGAL LAHIR", "tempat_tanggal_lahir", 59.4, "c"), ("NIK KTP", "nik", 33.1, "c"),
    ("ALAMAT", "alamat", 108.3, "c"), ("NOMOR REKENING", "no_rekening", 34.0, "c"),
    ("GMAIL", "email", 67.1, "c"), ("NO HP", "no_hp", 24.0, "c"),
]
KOLOM_KELUAR = [
    ("NO", None, 9.4, "c"), ("NAMA", "nama", 45.7, "l"), ("JABATAN", "jabatan", 23.3, "c"),
    ("TEMPAT/TANGGAL LAHIR", "tempat_tanggal_lahir", 59.4, "c"), ("NIK KTP", "nik", 33.1, "c"),
    ("ALAMAT", "alamat", 108.3, "c"), ("NO HP", "no_hp", 24.0, "c"), ("TANGGAL KELUAR", "tanggal_keluar", 24.0, "c"),
]


def _nama_sheet(nama: str, dipakai: set) -> str:
    n = re.sub(r"[\\/?*\[\]:]", " ", nama).strip()[:28] or "DATA"
    asli, i = n, 2
    while n.upper() in dipakai:
        n = f"{asli[:25]} {i}"
        i += 1
    dipakai.add(n.upper())
    return n


def _kotak(ws, rng, font=None, fill=None, align=TENGAH):
    for row in ws[rng]:
        for c in row:
            c.border = BORDER
            if fill:
                c.fill = fill
    first = ws[rng.split(":")[0]]
    if font:
        first.font = font
    first.alignment = align


def _header_tabel(ws, baris, kolom):
    ws.row_dimensions[baris].height = 55.5
    for i, (judul, _, lebar, _) in enumerate(kolom, 1):
        c = ws.cell(baris, i, judul)
        c.font, c.fill, c.alignment, c.border = Font(name="Calibri", size=18, bold=True), KUNING, TENGAH, BORDER
        ws.column_dimensions[L(i)].width = lebar


def _isi_tabel(ws, awal, kolom, data):
    font = Font(name="Calibri", size=16)
    for n, r in enumerate(data, 1):
        row = awal + n - 1
        ws.row_dimensions[row].height = 21
        for i, (_, kunci, _, rata) in enumerate(kolom, 1):
            nilai = n if kunci is None else (r.get(kunci) or "")
            c = ws.cell(row, i, nilai)
            c.font, c.border = font, BORDER
            c.alignment = KIRI if rata == "l" else TENGAH
            if kunci is not None:
                c.number_format = "@"
    return awal + len(data)


def _halaman(ws, judul_baris=None):
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = 9  # A4
    ws.sheet_properties.pageSetUpPr = PageSetupProperties(fitToPage=True)
    ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = 1, 0
    if judul_baris:
        ws.print_title_rows = judul_baris


def _sheet_area(wb, nama_sheet, nama_area, data, cfg):
    ws = wb.create_sheet(nama_sheet)
    kolom = KOLOM_AKTIF
    akhir = L(len(kolom))
    for i, h in enumerate([15, 26.25, 31.5, 26.25, 15], 1):
        ws.row_dimensions[i].height = h
    # blok judul
    ws.merge_cells("A1:B5")
    ws.merge_cells(f"C1:{akhir}2")
    ws.merge_cells(f"C3:{akhir}3")
    ws.merge_cells(f"C4:{akhir}5")
    ws["C1"], ws["C3"], ws["C4"] = cfg["perusahaan"], cfg["unit"], f"DATABASE AREA {nama_area.upper()}"
    _kotak(ws, "A1:B5")
    _kotak(ws, f"C1:{akhir}2", Font(name="Calibri", size=28, bold=True, color="5B9BD5"))
    _kotak(ws, f"C3:{akhir}3", Font(name="Calibri", size=24, bold=True, color="FF0000"))
    _kotak(ws, f"C4:{akhir}5", Font(name="Calibri", size=24, bold=True))
    try:
        from openpyxl.drawing.image import Image as XLImage
        img = XLImage(cfg.get("logo_path") or str(LOGO))
        img.height, img.width = 140, 140
        img.anchor = "A1"
        ws.add_image(img)
    except Exception:
        pass  # logo opsional (butuh Pillow)
    # tabel
    _header_tabel(ws, 6, kolom)
    akhir_data = _isi_tabel(ws, 7, kolom, data)
    # tanda tangan di 3 kolom terakhir
    k1, k3 = L(len(kolom) - 2), L(len(kolom))
    baris_ttd = akhir_data + 3
    for off, teks, tebal in [(0, cfg["label_penanggung_jawab"], False), (3, cfg["penandatangan"], True),
                             (4, cfg["jabatan_penandatangan"], True)]:
        if not teks:
            continue
        r = baris_ttd + off
        ws.merge_cells(f"{k1}{r}:{k3}{r}")
        c = ws[f"{k1}{r}"]
        c.value, c.font, c.alignment = teks, Font(name="Calibri", size=14, bold=tebal), TENGAH
    ws.freeze_panes = "A7"
    _halaman(ws, "6:6")
    return ws


def _sheet_keluar(wb, nama_sheet, data, dengan_area):
    ws = wb.create_sheet(nama_sheet)
    kolom = list(KOLOM_KELUAR)
    if dengan_area:
        kolom.insert(2, ("AREA", "area", 30.0, "c"))
    _header_tabel(ws, 1, kolom)
    _isi_tabel(ws, 2, kolom, data)
    ws.freeze_panes = "A2"
    _halaman(ws, "1:1")


def tulis_database(path, grup_area, keluar, cfg):
    """grup_area: [(nama_area, [baris aktif])]; keluar: [baris keluar]; cfg: pengaturan dokumen."""
    wb = Workbook()
    wb.remove(wb.active)
    dipakai: set = set()
    for nama_area, data in grup_area:
        nama = "DATA AKTIF" if len(grup_area) == 1 else nama_area
        _sheet_area(wb, _nama_sheet(nama, dipakai), nama_area, data, cfg)
    if keluar:
        _sheet_keluar(wb, _nama_sheet("ANGGOTA OUT", dipakai), keluar, dengan_area=len(grup_area) > 1)
    if not wb.sheetnames:
        wb.create_sheet("KOSONG")
    wb.save(path)
