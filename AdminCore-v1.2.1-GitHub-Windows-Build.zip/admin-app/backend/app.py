from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from sqlalchemy import inspect, text

from .api import router
from .database import Base, engine
from .paths import resource_path

Base.metadata.create_all(engine)


def _migrasi():
    """Database lama belum punya kolom area.perusahaan: tambahkan, isi bawaan VIP."""
    insp = inspect(engine)
    if "area" in insp.get_table_names():
        kolom = {c["name"] for c in insp.get_columns("area")}
        if "perusahaan" not in kolom:
            with engine.begin() as c:
                c.execute(text("ALTER TABLE area ADD COLUMN perusahaan VARCHAR(10) NOT NULL DEFAULT 'VIP'"))


_migrasi()

app = FastAPI(title="AdminCore", description="Administration Management System")
app.include_router(router)
app.mount("/", StaticFiles(directory=resource_path("frontend"), html=True), name="frontend")
