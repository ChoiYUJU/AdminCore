$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

if (-not (Test-Path ".venv")) {
    py -3 -m venv .venv
}
$Python = Join-Path (Get-Location) ".venv\Scripts\python.exe"
& $Python -m pip install --upgrade pip
& $Python -m pip install -r requirements-build.txt

if (Test-Path "build") { Remove-Item "build" -Recurse -Force }
if (Test-Path "dist") { Remove-Item "dist" -Recurse -Force }

& $Python -m PyInstaller --noconfirm --clean --onefile --windowed `
    --name AdminCore `
    --add-data "frontend;frontend" `
    --add-data "backend\assets;backend\assets" `
    --collect-all webview `
    --collect-all sqlalchemy `
    --hidden-import uvicorn.logging `
    --hidden-import uvicorn.loops.auto `
    --hidden-import uvicorn.protocols.http.auto `
    --hidden-import uvicorn.lifespan.on `
    --hidden-import webview.platforms.edgechromium `
    main.py

New-Item -ItemType Directory -Force -Path "release\portable" | Out-Null
Copy-Item "dist\AdminCore.exe" "release\portable\AdminCore.exe" -Force
Copy-Item "BACA_SAYA.txt" "release\portable\BACA_SAYA.txt" -Force
Write-Host "Portable build: release\portable\AdminCore.exe"
Write-Host "Installer source: packaging\AdminCore.iss"
