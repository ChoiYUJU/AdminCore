#define MyAppName "AdminCore"
#define MyAppVersion "1.2.0"
#define MyAppPublisher "AdminCore"
#define MyAppExeName "AdminCore.exe"

[Setup]
AppId={{D5B36D5B-1A91-4F77-A0B2-ACD2D5C1A120}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\AdminCore
DefaultGroupName=AdminCore
UninstallDisplayIcon={app}\{#MyAppExeName}
OutputDir=..\release\installer
OutputBaseFilename=AdminCore-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=lowest

[Files]
Source: "..\dist\AdminCore.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\BACA_SAYA.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\AdminCore"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\AdminCore"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Buat shortcut di Desktop"; GroupDescription: "Shortcut tambahan:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Jalankan AdminCore"; Flags: postinstall nowait skipifsilent

[UninstallDelete]
; Data pengguna di LocalAppData sengaja TIDAK dihapus saat uninstall.
