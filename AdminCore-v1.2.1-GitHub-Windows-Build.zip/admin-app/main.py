"""AdminCore - aplikasi administrasi desktop."""
import socket
import sys
import threading
import time
import webbrowser

import uvicorn

from backend.app import app

HOST, PORT = "127.0.0.1", 8765
URL = f"http://{HOST}:{PORT}"


def _port_tersedia(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        return sock.connect_ex((host, port)) != 0


def run_server():
    uvicorn.run(app, host=HOST, port=PORT, log_level="warning", access_log=False)


if __name__ == "__main__":
    if not _port_tersedia(HOST, PORT):
        # Jangan membuka instance kedua yang berpotensi memakai server milik aplikasi lain.
        print(f"Port {PORT} sedang digunakan. Tutup AdminCore yang masih berjalan lalu coba lagi.")
        raise SystemExit(1)

    t = threading.Thread(target=run_server, daemon=True)
    t.start()
    for _ in range(50):
        try:
            with socket.create_connection((HOST, PORT), timeout=0.2):
                break
        except OSError:
            time.sleep(0.1)
    else:
        raise SystemExit("Server AdminCore gagal dijalankan.")

    try:
        import webview
        webview.create_window("AdminCore · Administration Management", URL, width=1320, height=820)
        if sys.platform.startswith("linux"):
            webview.start(gui="qt")
        else:
            webview.start()
    except ImportError:
        webbrowser.open(URL)
        t.join()
